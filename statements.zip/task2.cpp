#include <iostream>
#include <cstdlib>
using namespace std;
int main() {
	for (int i=26; i>=15; i--) {
		cout << i << " ";
	}
	return 0;
}