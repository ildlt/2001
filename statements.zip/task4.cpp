#include <iostream>
#include <cstdlib>
using namespace std;
int main() {
	for (int i=1; i<=10; i++) {
		cout << "9 * " << i << " = " << 9*i << endl;
	}
	return 0;
}