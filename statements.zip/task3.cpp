#include <iostream>
#include <cstdlib>
using namespace std;
int main() {
	for (int i=1; i<=10; i++) {
		cout << "5 * " << i << " = " << 5*i << endl;
	}
	return 0;
}